## 0.0.1

* Initial release with basic features

# 0.0.3

* Editor specific settings
* Video addition feature


# 0.0.6
* Refactor for flutter 3.10