import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class Button {
  String? slug;
  IconData? icon;
  Function? onTap;

  Button({this.slug, this.icon, this.onTap});
}
