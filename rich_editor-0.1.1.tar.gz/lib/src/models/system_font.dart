class SystemFont {
  String? name;
  String? path;

  SystemFont(String name, String path) {
    this.name = name;
    this.path = path;
  }
}
