class LoadedListener {
  editorLoaded() {}
}
