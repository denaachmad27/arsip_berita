class HtmlChangedListener {
  htmlChangedAsync(String html) {}
}
