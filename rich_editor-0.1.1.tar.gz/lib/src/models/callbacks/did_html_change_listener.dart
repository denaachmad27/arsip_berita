class DidHtmlChangeListener {
  didHtmlChange(bool didHtmlChange) {}
}
