class GetCurrentHtmlCallback {
  htmlRetrieved(String html) {}
}
