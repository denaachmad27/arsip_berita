package com.jideguru.example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
